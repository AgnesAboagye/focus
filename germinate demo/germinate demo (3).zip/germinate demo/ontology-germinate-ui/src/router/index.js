import { createRouter, createWebHistory } from "vue-router";

import HomePage from "../views/HomePage.vue";

// Standard Germinate pages
import Germplasm from "../views/GermplasmData.vue";
import GenotypicData from "../views/GenotypesData.vue";
import TrialsData from "../views/TrialsData.vue";
import ClimateData from "../views/ClimateData.vue";

// Semantic pages
import TraitBrowser from "../views/semantics/TraitBrowser.vue";
import DatasetExplorer from "../views/semantics/DatasetExplorer.vue";
import SemanticComparison from "../views/semantics/SemanticComparison.vue";
import SpeciesComparison from "../views/semantics/SpeciesComparison.vue";
import OntologyTermSearch from "../views/semantics/OntologyTermSearch.vue";

const routes = [
  {
    path: "/",
    name: "home",
    component: HomePage,
  },
  {
    path: "/germplasm",
    name: "germplasm",
    component: Germplasm,
  },
  {
    path: "/genotypic-data",
    name: "genotypic-data",
    component: GenotypicData,
  },
  {
    path: "/trials-data",
    name: "trials-data",
    component: TrialsData,
  },
  {
    path: "/climate-data",
    name: "climate-data",
    component: ClimateData,
  },
  {
    path: "/semantic/traits",
    name: "trait-browser",
    component: TraitBrowser,
  },
  {
    path: "/semantic/datasets",
    name: "dataset-explorer",
    component: DatasetExplorer,
  },
  {
    path: "/semantic/comparison",
    name: "semantic-comparison",
    component: SemanticComparison,
  },
  {
    path: "/semantic/species-comparison",
    name: "species-comparison",
    component: SpeciesComparison,
  },
  {
    path: "/semantic/ontology-search",
    name: "ontology-search",
    component: OntologyTermSearch,
  },
];

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
});

export default router;