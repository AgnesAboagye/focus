import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";
import { fileURLToPath, URL } from "node:url";

export default defineConfig({
  // Deployment address: https://germinate.hutton.ac.uk/focus
  base: "/focus/",

  plugins: [vue()],

  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },

  server: {
    host: "127.0.0.1",
    port: 5173,

    proxy: {
      "/focus/brapi": {
        target: "http://127.0.0.1:8001",
        changeOrigin: true,
        rewrite: (requestPath) => requestPath.replace(/^\/focus/, ""),
      },

      "/focus/api": {
        target: "http://127.0.0.1:8001",
        changeOrigin: true,
        rewrite: (requestPath) => requestPath.replace(/^\/focus/, ""),
      },
    },
  },
});